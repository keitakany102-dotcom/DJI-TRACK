package com.app.djitrack.controller;

import com.app.djitrack.entity.Reclamation;
import com.app.djitrack.service.ReclamationService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/reclamations")
@RequiredArgsConstructor
public class ReclamationController {

    private final ReclamationService service;

    // GET ALL - Admin et Agent voient toutes, Abonné voit les siennes (filtré côté frontend via /abonne/{id})
    @GetMapping
    @PreAuthorize("hasAnyRole('ADMIN', 'AGENT')")
    public ResponseEntity<List<Reclamation>> getAll() {
        return ResponseEntity.ok(service.getAll());
    }

    // GET par abonné - l'abonné voit ses réclamations
    @GetMapping("/abonne/{abonneId}")
    public ResponseEntity<List<Reclamation>> getByAbonne(@PathVariable Long abonneId) {
        List<Reclamation> all = service.getAll();
        List<Reclamation> filtered = all.stream()
                .filter(r -> r.getAbonne() != null && abonneId.equals(r.getAbonne().getId()))
                .toList();
        return ResponseEntity.ok(filtered);
    }

    // CREATE - Abonnés (et agents/admins) peuvent créer
    @PostMapping
    public ResponseEntity<?> create(@RequestBody Reclamation reclamation) {
        try {
            if (reclamation.getStatut() == null) {
                reclamation.setStatut("EN ATTENTE");
            }
            if (reclamation.getDateDepot() == null) {
                reclamation.setDateDepot(java.time.LocalDate.now());
            }
            return ResponseEntity.ok(service.save(reclamation));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body("Erreur: " + e.getMessage());
        }
    }

    // REPONDRE - Admin et Agent seulement
    @PutMapping("/{id}/repondre")
    @PreAuthorize("hasAnyRole('ADMIN', 'AGENT')")
    public ResponseEntity<?> repondre(
            @PathVariable Long id,
            @RequestBody Map<String, String> body,
            Authentication authentication) {
        try {
            String reponse = body.get("reponse");
            if (reponse == null || reponse.isEmpty()) {
                return ResponseEntity.badRequest().body("La réponse ne peut pas être vide");
            }
            String repondantNom = authentication.getName(); // email du répondant
            Reclamation updated = service.repondre(id, reponse, repondantNom);
            return ResponseEntity.ok(updated);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body("Erreur: " + e.getMessage());
        }
    }

    // DELETE - Admin seulement
    @DeleteMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<?> delete(@PathVariable Long id) {
        try {
            service.deleteById(id);
            return ResponseEntity.ok("Réclamation supprimée");
        } catch (Exception e) {
            return ResponseEntity.badRequest().body("Erreur: " + e.getMessage());
        }
    }
}
