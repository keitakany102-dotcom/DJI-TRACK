package com.app.djitrack.service;

import com.app.djitrack.entity.Reclamation;
import com.app.djitrack.repository.ReclamationRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class ReclamationService {

    private final ReclamationRepository repository;

    public List<Reclamation> getAll() {
        return repository.findAll();
    }

    public Optional<Reclamation> getById(Long id) {
        return repository.findById(id);
    }

    public Reclamation save(Reclamation reclamation) {
        return repository.save(reclamation);
    }

    public Reclamation repondre(Long id, String reponse, String repondantNom) {
        Reclamation rec = repository.findById(id)
                .orElseThrow(() -> new RuntimeException("Réclamation introuvable"));
        rec.setReponse(reponse);
        rec.setRepondantNom(repondantNom);
        rec.setDateReponse(LocalDate.now());
        rec.setStatut("TRAITEE");
        return repository.save(rec);
    }

    public void deleteById(Long id) {
        repository.deleteById(id);
    }
}
